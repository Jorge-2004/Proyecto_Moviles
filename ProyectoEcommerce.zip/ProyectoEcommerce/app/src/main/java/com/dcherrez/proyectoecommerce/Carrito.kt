package com.dcherrez.proyectoecommerce

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.dcherrez.proyecto.databinding.ActivityCarritoBinding

class Carrito : AppCompatActivity() {
    private lateinit var binding: ActivityCarritoBinding
    private val productosCarrito = mutableListOf<Productos>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCarritoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Recibir el JSON del carrito desde el Intent
        val carritoJson = intent.getStringExtra("carrito")

        if (!carritoJson.isNullOrEmpty()) {
            // Deserializar el carrito desde el JSON
            val gson = Gson()
            val tipo = object : TypeToken<List<Productos>>() {}.type
            val productos = gson.fromJson<List<Productos>>(carritoJson, tipo)

            // Agregar los productos al carrito y mostrarlos
            productosCarrito.addAll(productos)
            mostrarProductosEnCarrito()
        } else {
            Toast.makeText(this, "Carrito vacío", Toast.LENGTH_SHORT).show()
        }

        // Acción del botón de inicio
        binding.linearLayoutInicio.setOnClickListener {
            val intent = Intent(this, Inicio::class.java)
            startActivity(intent)
        }
        binding.linearLayoutUsuario.setOnClickListener {
            val intent = Intent(this, Usuario::class.java)
            startActivity(intent)
        }

        // Acción del botón de productos
        binding.linearLayoutProductos.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Acción del botón de checkout (finalizar compra)
        binding.btnCheckout.setOnClickListener {
            if (productosCarrito.isNotEmpty()) {
                // Redirigir a la actividad de pago
                val intent = Intent(this, MetodoPago::class.java)

                // Convertir el carrito de productos a JSON
                val gson = Gson()
                val carritoJson = gson.toJson(productosCarrito)

                // Pasar el carrito al método de pago
                intent.putExtra("carrito", carritoJson)

                // Iniciar la actividad de pago
                startActivity(intent)
            } else {
                Toast.makeText(this, "Tu carrito está vacío", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Función que configura el RecyclerView con los productos del carrito
    private fun mostrarProductosEnCarrito() {
        val adaptadorCarrito = AdaptadorCarrito(productosCarrito)
        binding.rvProductos.layoutManager = LinearLayoutManager(this)
        binding.rvProductos.adapter = adaptadorCarrito
        calcularTotal()
    }

    private fun calcularTotal() {
        var total = 0.0
        // Recorrer todos los productos del carrito para sumar el subtotal de cada uno
        for (producto in productosCarrito) {
            total += producto.precio // Si tienes cantidad, multiplícalo por la cantidad
        }
        // Actualizar el TextView con el total
        binding.tvTotalAmount.text = "Total: S/.${"%.2f".format(total)}"
    }
}
