package com.dcherrez.proyectoecommerce
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.dcherrez.proyecto.databinding.ActivityMetodoPagoBinding
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class MetodoPago : AppCompatActivity() {
    private lateinit var binding: ActivityMetodoPagoBinding
    private val productosCarrito = mutableListOf<Productos>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMetodoPagoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Recibir el carrito desde el Intent
        val carritoJson = intent.getStringExtra("carrito")

        if (!carritoJson.isNullOrEmpty()) {
            // Deserializar el carrito desde el JSON
            val gson = Gson()
            val tipo = object : TypeToken<List<Productos>>() {}.type
            val productos = gson.fromJson<List<Productos>>(carritoJson, tipo)

            productosCarrito.addAll(productos)
            mostrarProductosEnMetodoPago()
        } else {
            Toast.makeText(this, "No se recibió el carrito", Toast.LENGTH_SHORT).show()
        }

        binding.linearLayoutInicio.setOnClickListener {
            val intent = Intent(this, Inicio::class.java)
            startActivity(intent)
        }
        binding.linearLayoutUsuario.setOnClickListener {
            val intent = Intent(this, Usuario::class.java)
            startActivity(intent)
        }

    }
    private fun mostrarProductosEnMetodoPago() {
        // Aquí puedes configurar un RecyclerView para mostrar los productos en la pantalla de pago
        // También puedes mostrar el total de la compra, etc.
    }

}