import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dcherrez.proyecto.R
import com.dcherrez.proyectoecommerce.Productos

// Adaptador para mostrar productos en un RecyclerView
class Adaptador(
    private val onAddToCartClick: (Productos) -> Unit  // Callback para el evento de agregar al carrito
) : RecyclerView.Adapter<Adaptador.MiViewHolder>() {

    private var listaProductos = ArrayList<Productos>()

    // Método para agregar productos al adaptador
    fun agregarProductos(productos: ArrayList<Productos>) {
        listaProductos.clear()
        listaProductos.addAll(productos)
        notifyDataSetChanged()  // Notificamos que los datos han cambiado
    }

    // ViewHolder que mantiene las vistas para cada fila de producto
    class MiViewHolder(view: View, private val onAddToCartClick: (Productos) -> Unit) : RecyclerView.ViewHolder(view) {
        private val filaNombre: TextView = view.findViewById(R.id.filaNombreProducto)
        private val filaPrecio: TextView = view.findViewById(R.id.filaPrecioProducto)
        private val filaImagen: ImageView = view.findViewById(R.id.filaImagenProducto)
        private val botonCarrito: ImageButton = view.findViewById(R.id.filaCarrito)

        // Función para llenar los datos del producto en las vistas
        fun rellenarFila(producto: Productos) {
            filaNombre.text = producto.nombre
            filaPrecio.text = "Precio: $${producto.precio}"

            // Cargar la imagen con Glide
            Glide.with(itemView.context)
                .load(producto.imagenUrl)
                .placeholder(R.drawable.ic_carrito)
                .error(R.drawable.ic_carrito)
                .into(filaImagen)

            // Configuramos el listener del botón del carrito
            botonCarrito.setOnClickListener {
                // Llamamos al callback para agregar al carrito
                onAddToCartClick(producto)
            }
        }
    }

    // Creación del ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MiViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.fila, parent, false)
        return MiViewHolder(view, onAddToCartClick)  // Pasamos el callback al ViewHolder
    }

    // Vinculamos los datos del producto al ViewHolder
    override fun onBindViewHolder(holder: MiViewHolder, position: Int) {
        val productoItem = listaProductos[position]
        holder.rellenarFila(productoItem)  // Llenamos los datos del producto en el ViewHolder
    }

    // Devolvemos el número de elementos en la lista de productos
    override fun getItemCount(): Int {
        return listaProductos.size
    }
}
