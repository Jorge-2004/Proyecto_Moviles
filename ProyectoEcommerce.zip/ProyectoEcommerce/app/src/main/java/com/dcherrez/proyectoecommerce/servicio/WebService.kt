package com.dcherrez.proyectoecommerce

import com.dcherrez.proyectoecommerce.Usuarios
import com.google.gson.GsonBuilder
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

object AppConstantes {
    const val BASE_URL = "http://192.168.1.44:3000" // Asegúrate que esta IP sea accesible
}

interface WebService {
    @GET("/productos")
    suspend fun obtenerProductos(): Response<ProductosResponse>

    @POST("/productos/agregar")
    suspend fun agregarProducto(@Body producto: Productos): Response<ResponseBody>

    @PUT("/productos/modificar/{id}")
    suspend fun modificarProducto(
        @Path("id") id: Int,
        @Body producto: Productos
    ): Response<ResponseBody>

    @DELETE("/productos/eliminar/{id}")
    suspend fun eliminarProducto(@Path("id") id: Int): Response<ResponseBody>

    @GET("/productos/{id}")
    suspend fun buscarProducto(@Path("id") id: Int): Response<Productos>

    @POST("/usuarios/agregar")
    suspend fun agregarUsuario(@Body usuario: Usuarios): Response<ResponseBody>

    @GET("usuarios/buscarPorEmail/{email}")
    suspend fun buscarUsuarioPorEmail(@Path("email") email: String): Response<Usuarios>

}

object RetrofitCliente {
    val webService: WebService by lazy {
        Retrofit.Builder()
            .baseUrl(AppConstantes.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
            .build()
            .create(WebService::class.java)
    }
}
