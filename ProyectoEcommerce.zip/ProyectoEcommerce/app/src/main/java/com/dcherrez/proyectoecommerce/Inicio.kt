package com.dcherrez.proyectoecommerce

import Adaptador
import android.R
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager2.widget.ViewPager2
import com.dcherrez.proyecto.databinding.ActivityInicioBinding
import com.dcherrez.proyectoecommerce.interfaz.CarruselAdapter
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException


class Inicio : AppCompatActivity() {

    private lateinit var binding: ActivityInicioBinding
    private var listaProductos = ArrayList<Productos>()
    private val adaptador: Adaptador by lazy {
        Adaptador { producto -> agregarAlCarrito(producto) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Inicializa el binding correctamente
        binding = ActivityInicioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configuración del RecyclerView para productos
        binding.rvProductos.layoutManager = LinearLayoutManager(this)
        binding.rvProductos.adapter = adaptador

        // Lista de URLs para las imágenes del carrusel
        val imagenesCarrusel = listOf(
            "https://thumbs.dreamstime.com/z/plantilla-de-banner-venta-para-tienda-moda-con-ropa-mujer-antecedentes-oferta-descuento-en-minorista-moderna-promoci%C3%B3n-prendas-244956623.jpg", // Imagen 1
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1f7G86hyOQgIZM-wA74iZw-JuOTwNKceEb_hHX9XFe16w8gbelSCLQJ20AbzjYw1lfik&usqp=CAU", // Imagen 2
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJAjvoUX7dblkh6Z5X-ltpOGfsJRwKvpVnlg&s"  // Imagen 3
        )

        // Configuración de ViewPager2 para carrusel
        val viewPager = findViewById<ViewPager2>(com.dcherrez.proyecto.R.id.viewPager)
        val adaptadorCarrusel = CarruselAdapter(imagenesCarrusel, this)
        viewPager.adapter = adaptadorCarrusel


        // Configuración para manejar los márgenes de la pantalla
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }



        // Cargar productos de la API
        cargarProductos()

        // Configurar botón de carrito
        binding.linearLayoutCarrito.setOnClickListener {
            val intent = Intent(this, Carrito::class.java)

            // Obtener los productos del carrito desde CarritoManager
            val carrito = CarritoManager.getProductosCarrito()

            // Convertir el carrito a JSON (si deseas pasar los datos a la nueva actividad)
            val gson = Gson()
            val carritoJson = gson.toJson(carrito)

            // Pasar el carrito como Extra
            intent.putExtra("carrito", carritoJson)

            // Iniciar la actividad del carrito
            startActivity(intent)
        }

        // Configurar botón de inicio (si es necesario)
        binding.linearLayoutProductos.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        binding.linearLayoutUsuario.setOnClickListener {
            val intent = Intent(this, Usuario::class.java)
            startActivity(intent)
        }

    }

    private fun cargarProductos() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitCliente.webService.obtenerProductos()
                if (response.isSuccessful && response.body() != null) {
                    listaProductos = response.body()!!.listaProductos
                    withContext(Dispatchers.Main) {
                        adaptador.agregarProductos(listaProductos)
                    }
                } else {
                    mostrarError("Error al cargar productos: ${response.message()}")
                }
            } catch (e: HttpException) {
                mostrarError("Error de conexión: ${e.message()}")
            } catch (e: Exception) {
                mostrarError("Error inesperado: ${e.message}")
            }
        }
    }

    private fun agregarAlCarrito(producto: Productos) {
        // Usar CarritoManager para agregar el producto al carrito global
        CarritoManager.agregarProducto(producto)

        // Mostrar mensaje al usuario
        AlertDialog.Builder(this)
            .setTitle("Producto Agregado")
            .setMessage("${producto.nombre} ha sido añadido al carrito.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun mostrarError(mensaje: String) {
        runOnUiThread {
            val ventana = AlertDialog.Builder(this)
            ventana.setTitle("Información")
            ventana.setMessage(mensaje)
            ventana.setPositiveButton("Aceptar", null)
            ventana.create().show()
        }
    }
}
