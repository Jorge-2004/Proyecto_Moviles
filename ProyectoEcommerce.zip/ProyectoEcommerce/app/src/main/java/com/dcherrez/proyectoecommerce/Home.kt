package com.dcherrez.proyectoecommerce

import com.dcherrez.proyecto.R
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)

        // Configuración de WindowInsets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.home)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Enlaces a TextViews para navegación
        val registerTextView: TextView = findViewById(R.id.textView5)
        registerTextView.setOnClickListener {
            val intent = Intent(this, Register::class.java)
            startActivity(intent)
        }

        val recuperarTextView: TextView = findViewById(R.id.textView3)
        recuperarTextView.setOnClickListener {
            val intent = Intent(this, RecuperarContrana::class.java)
            startActivity(intent)
        }

        // Obtén referencias a los campos de correo y contraseña
        val emailEditText: EditText = findViewById(R.id.editTextText) // Asegúrate de que el ID coincida con el XML
        val passwordEditText: EditText = findViewById(R.id.editTextText2) // Asegúrate de que el ID coincida con el XML
        val loginButton: Button = findViewById(R.id.button2)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Llama al servicio para obtener usuarios y validar las credenciales
            UsuarioService.obtenerUsuarios(this) { usuarios ->
                val usuarioValido = usuarios.find {
                    it.email == email && it.contraseña == password
                }

                if (usuarioValido != null) {
                    // Inicia MainActivity si las credenciales son correctas
                    val intent = Intent(this, Inicio::class.java)
                    startActivity(intent)
                    finish() // Cierra la actividad actual
                } else {
                    // Muestra un mensaje de error si las credenciales son incorrectas
                    Toast.makeText(this, "Correo o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
