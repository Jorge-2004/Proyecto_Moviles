package com.dcherrez.proyectoecommerce.interfaz;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.dcherrez.proyecto.R;

import java.util.List;

public class CarruselAdapter extends RecyclerView.Adapter<CarruselAdapter.CarruselViewHolder> {

    private List<String> imagenes;  // Lista de URLs de las imágenes
    private Context context;         // Necesario para Glide

    // Constructor para pasar la lista de URLs
    public CarruselAdapter(List<String> imagenes, Context context) {
        this.imagenes = imagenes;
        this.context = context;
    }

    // Método para crear la vista de cada item del carrusel
    @NonNull
    @Override
    public CarruselViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflar el diseño del item
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_imagen_carrusel, parent, false);
        return new CarruselViewHolder(view);
    }

    // Método para asociar los datos de las imágenes con los elementos de la vista
    @Override
    public void onBindViewHolder(@NonNull CarruselViewHolder holder, int position) {
        // Usar Glide para cargar la imagen desde la URL y ajustar el tamaño
        Glide.with(context)
                .load(imagenes.get(position))    // Cargar la imagen desde la URL
                .centerCrop()                   // Esto asegura que la imagen se ajuste y recorte para llenar el espacio sin distorsionarse
                .into(holder.imagenView);       // Establecer la imagen en el ImageView
    }


    // Método que devuelve el número de elementos en la lista
    @Override
    public int getItemCount() {
        return imagenes.size();
    }

    // Clase interna para manejar la vista de cada item
    public static class CarruselViewHolder extends RecyclerView.ViewHolder {
        ImageView imagenView;

        public CarruselViewHolder(View itemView) {
            super(itemView);
            imagenView = itemView.findViewById(R.id.imgCarrusel); // Asegúrate de tener el ImageView con este ID en el layout
        }
    }

}
