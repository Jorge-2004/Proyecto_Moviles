package com.dcherrez.proyectoecommerce

class Productos(
    var idProducto: Int,
    var nombre: String,
    var descripcion: String,
    var precio: Double,
    var stock: Int,
    var imagenUrl: String,
    var categoriaId: Int
) {
    var cantidad: Int = 1

    override fun equals(obj: Any?): Boolean {
        if (this === obj) return true
        if (obj == null || javaClass != obj.javaClass) return false
        val producto = obj as Productos
        return idProducto == producto.idProducto  // Comparar idProducto correctamente
    }

    override fun hashCode(): Int {
        return idProducto // Usar idProducto para generar el hashCode
    }
}
