import android.app.Activity
import android.util.Log
import com.dcherrez.proyectoecommerce.Usuarios
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray

object UsuarioService {
    private const val BASE_URL = "http://192.168.1.44:3000/usuarios"
    private val client = OkHttpClient()

    fun obtenerUsuarios(context: Activity, callback: (List<Usuarios>) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val request = Request.Builder().url(BASE_URL).build()
                val response: Response = client.newCall(request).execute()

                if (response.isSuccessful) {
                    val respuestaJson = response.body()?.string()
                    val usuarios = mutableListOf<Usuarios>()

                    respuestaJson?.let {
                        val jsonArray = JSONArray(it)
                        for (i in 0 until jsonArray.length()) {
                            val jsonObject = jsonArray.getJSONObject(i)
                            val usuario = Usuarios(
                                id = jsonObject.getInt("id"),
                                nombre = jsonObject.getString("nombre"),
                                email = jsonObject.getString("email"),
                                contraseña = jsonObject.getString("contraseña")
                            )
                            usuarios.add(usuario)
                        }

                        // Llama al callback en el hilo principal
                        withContext(Dispatchers.Main) {
                            callback(usuarios)
                        }
                    } ?: Log.e("UsuarioService", "Cuerpo de respuesta nulo.")
                } else {
                    Log.e("UsuarioService", "Error al obtener usuarios: ${response.message()}")
                }
            } catch (e: Exception) {
                Log.e("UsuarioService", "Error de conexión", e)
            }
        }
    }
}
