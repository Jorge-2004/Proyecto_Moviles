package com.dcherrez.proyectoecommerce

import Adaptador
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException

import com.dcherrez.proyecto.databinding.ActivityMainBinding
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var listaProductos = ArrayList<Productos>()
    private val adaptador: Adaptador by lazy {
        Adaptador { producto -> agregarAlCarrito(producto) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnMapa.setOnClickListener {
            val intent = Intent(this, MapaActivity2::class.java)
            startActivity(intent)

        }

        // Configuración para manejar los márgenes de la pantalla
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Configuración del RecyclerView
        binding.rvProductos.layoutManager = LinearLayoutManager(this)
        binding.rvProductos.adapter = adaptador

        // Cargar productos de la API
        cargarProductos()

        binding.linearLayoutCarrito.setOnClickListener {
            // Redirigir a la pantalla del carrito
            val intent = Intent(this, Carrito::class.java)

            // Obtener los productos del carrito desde CarritoManager
            val carrito = CarritoManager.getProductosCarrito()

            // Convertir el carrito a JSON (si deseas pasar los datos a la nueva actividad)
            val gson = Gson()
            val carritoJson = gson.toJson(carrito)

            // Pasar el carrito como Extra
            intent.putExtra("carrito", carritoJson)

            // Iniciar la actividad del carrito
            startActivity(intent)
        }
        binding.linearLayoutInicio.setOnClickListener {
            val intent = Intent(this, Inicio::class.java)
            startActivity(intent)
        }
        binding.linearLayoutUsuario.setOnClickListener {
            val intent = Intent(this, Usuario::class.java)
            startActivity(intent)
        }

    }

    private fun cargarProductos() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitCliente.webService.obtenerProductos()
                if (response.isSuccessful && response.body() != null) {
                    listaProductos = response.body()!!.listaProductos
                    withContext(Dispatchers.Main) {
                        adaptador.agregarProductos(listaProductos)
                    }
                } else {
                    mostrarError("Error al cargar productos: ${response.message()}")
                }
            } catch (e: HttpException) {
                mostrarError("Error de conexión: ${e.message()}")
            } catch (e: Exception) {
                mostrarError("Error inesperado: ${e.message}")
            }
        }
    }

    private fun agregarAlCarrito(producto: Productos) {
        // Usar CarritoManager para agregar el producto al carrito global
        CarritoManager.agregarProducto(producto)

        // Mostrar mensaje al usuario
        AlertDialog.Builder(this)
            .setTitle("Producto Agregado")
            .setMessage("${producto.nombre} ha sido añadido al carrito.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun mostrarError(mensaje: String) {
        runOnUiThread {
            val ventana = AlertDialog.Builder(this)
            ventana.setTitle("Información")
            ventana.setMessage(mensaje)
            ventana.setPositiveButton("Aceptar", null)
            ventana.create().show()
        }
    }

}
