package com.dcherrez.proyectoecommerce

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.dcherrez.proyecto.R
import com.dcherrez.proyecto.databinding.ActivityMainBinding

class RecuperarContrana : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recuperar_contrana)

        val editTextEmail = findViewById<EditText>(R.id.editTextEmail)
        val buttonRecuperar = findViewById<Button>(R.id.buttonRecuperar)
        val textViewIniciarSesion = findViewById<TextView>(R.id.textViewIniciarSesion)

        // Acción del botón de recuperación
        buttonRecuperar.setOnClickListener {
            // Aquí puedes implementar la lógica para enviar un correo de recuperación
            // Por ejemplo, validar el correo ingresado y enviar la solicitud.
        }

        textViewIniciarSesion.setOnClickListener {
            // Iniciar la actividad de inicio de sesión
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
        }
    }
}
