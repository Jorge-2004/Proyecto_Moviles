package com.dcherrez.proyectoecommerce


import com.google.gson.annotations.SerializedName

data class ProductosResponse(
    @SerializedName("listaProductos") var listaProductos: ArrayList<Productos>
)
