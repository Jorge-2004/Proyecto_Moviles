package com.dcherrez.proyectoecommerce;

import java.util.ArrayList;
import java.util.List;
public class CarritoManager {

    private static final List<Productos> productosCarrito = new ArrayList<>();

    public static List<Productos> getProductosCarrito() {
        return productosCarrito;
    }

    public static void agregarProducto(Productos producto) {
        // Buscar si el producto ya existe en el carrito
        Productos productoExistente = null;
        for (Productos p : productosCarrito) {
            if (p.getIdProducto() == producto.getIdProducto()) {
                productoExistente = p;
                break;
            }
        }

        // Si el producto existe, actualizar la cantidad
        if (productoExistente != null) {
            productoExistente.setCantidad(productoExistente.getCantidad() + producto.getCantidad());
        } else {
            // Si no existe, agregar el producto al carrito
            productosCarrito.add(producto);
        }
    }

    public static void eliminarProducto(Productos producto) {
        productosCarrito.remove(producto);
    }

    public static void vaciarCarrito() {
        productosCarrito.clear();
    }

    public static double calcularTotal() {
        double total = 0.0;
        for (Productos producto : productosCarrito) {
            total += producto.getPrecio() * producto.getCantidad();
        }
        return total;
    }
}
