package com.dcherrez.proyectoecommerce


import com.dcherrez.proyectoecommerce.Usuarios
import com.google.gson.annotations.SerializedName

data class RespuestaUsuarios(
    @SerializedName("usuarios") var listaUsuarios: ArrayList<Usuarios>
)
