package com.dcherrez.proyectoecommerce

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.dcherrez.proyecto.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import retrofit2.Response


class Register : AppCompatActivity() {

    private lateinit var editTextNombre: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextContraseña: EditText
    private lateinit var buttonRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        editTextNombre = findViewById(R.id.editTextNombre)
        editTextEmail = findViewById(R.id.editTextEmail)
        editTextContraseña = findViewById(R.id.editTextContraseña)
        buttonRegister = findViewById(R.id.buttonRegister)

        buttonRegister.setOnClickListener {
            val nombre = editTextNombre.text.toString()
            val email = editTextEmail.text.toString()
            val contraseña = editTextContraseña.text.toString()

            // Validaciones
            if (nombre.isEmpty() || email.isEmpty() || contraseña.isEmpty()) {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            verificarUsuarioYRegistrar(nombre, email, contraseña)
        }
        val registerTextView: TextView = findViewById(R.id.textViewLogin)  // Referencia al TextView
        registerTextView.setOnClickListener {
            val intent = Intent(this, Home::class.java)  // Redirigir a la actividad Home
            startActivity(intent)
        }
    }

    private fun verificarUsuarioYRegistrar(nombre: String, email: String, contraseña: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Verificar si el usuario ya existe
                val response = RetrofitCliente.webService.buscarUsuarioPorEmail(email) // Método que debes agregar
                if (response.isSuccessful && response.body() != null) {
                    // Usuario ya existe
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@Register, "El correo ya está registrado", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    // Usuario no existe, proceder a agregar
                    val nuevoUsuario = Usuarios(id = generarId(), nombre = nombre, email = email, contraseña = contraseña)
                    val registroResponse = RetrofitCliente.webService.agregarUsuario(nuevoUsuario)

                    withContext(Dispatchers.Main) {
                        if (registroResponse.isSuccessful) {
                            // Mostrar mensaje de éxito solo si el registro fue exitoso
                            Toast.makeText(this@Register, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show()

                            // Redirigir a la actividad de inicio de sesión
                            val intent = Intent(this@Register, Home::class.java)
                            startActivity(intent)
                            finish() // Opcional: cierra la actividad de registro
                        } else {
                            // Mensaje de error en caso de que el registro falle
                            Toast.makeText(this@Register, "Error al registrar usuario", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } catch (e: HttpException) {
                Log.e("Register", "Error en la consulta de usuario: ${e.message()}")
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@Register, "Error al verificar usuario", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun generarId(): Int {
        // Implementa tu lógica para generar un ID único
        return (1..1000).random() // Solo un ejemplo
    }
}
