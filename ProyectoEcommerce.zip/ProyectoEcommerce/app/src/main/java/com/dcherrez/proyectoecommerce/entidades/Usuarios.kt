package com.dcherrez.proyectoecommerce


data class Usuarios(
    val id: Int,
    val nombre: String,
    val email: String,
    var contraseña: String
)
