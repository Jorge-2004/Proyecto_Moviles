package com.dcherrez.proyectoecommerce

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dcherrez.proyecto.databinding.ActivityUsuarioBinding
import com.google.gson.Gson

class Usuario : AppCompatActivity() {
    private lateinit var binding: ActivityUsuarioBinding
    private lateinit var usuario: Usuarios

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializa el binding para inflar las vistas
        binding = ActivityUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        usuario = Usuarios(id = 1, nombre = "Daniel Cherrez", email = "DanielCherrez1587@gmail.com", contraseña = "Daniel123456")

        // Asigna los valores a las vistas de la interfaz de usuario
        binding.tvNombre.text = "Nombre: ${usuario.nombre}"
        binding.tvCorreo.text = "Correo: ${usuario.email}"


        binding.btnCerrarSesion.setOnClickListener {
            // Borrar los datos de sesión (si se están usando SharedPreferences)
            val preferences = getSharedPreferences("user_session", MODE_PRIVATE)
            preferences.edit().clear().apply()

            // Navegar a la pantalla de inicio de sesión
            val intent = Intent(this, Home::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        // Configuración para el acceso al carrito de compras
        binding.linearLayoutCarrito.setOnClickListener {
            val intent = Intent(this, Carrito::class.java)
            // Convierte los productos del carrito a formato JSON utilizando Gson
            val carritoJson = Gson().toJson(CarritoManager.getProductosCarrito())
            // Envia los datos del carrito a la siguiente actividad
            intent.putExtra("carrito", carritoJson)
            startActivity(intent)
        }

        // Navegación a la pantalla de productos
        binding.linearLayoutProductos.setOnClickListener {
            startActivity(Intent(this, Productos::class.java))
        }

        // Navegación a la pantalla principal
        binding.linearLayoutInicio.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

    }
}
