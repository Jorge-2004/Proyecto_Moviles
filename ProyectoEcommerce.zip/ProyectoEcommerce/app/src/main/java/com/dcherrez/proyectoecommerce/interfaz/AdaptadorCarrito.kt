package com.dcherrez.proyectoecommerce

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dcherrez.proyecto.databinding.ItemCartBinding
import com.bumptech.glide.Glide
import com.dcherrez.proyecto.R

class AdaptadorCarrito(private val listaProductos: List<Productos>) :
    RecyclerView.Adapter<AdaptadorCarrito.ProductoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductoViewHolder {
        // Inflar el layout para cada item del carrito
        val binding = ItemCartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductoViewHolder, position: Int) {
        // Llenar el ViewHolder con los datos del producto
        val producto = listaProductos[position]
        holder.bind(producto)
    }

    override fun getItemCount(): Int = listaProductos.size  // Regresar la cantidad de productos en el carrito

    inner class ProductoViewHolder(private val binding: ItemCartBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(producto: Productos) {
            // Llenar los datos del producto en el layout del item

            // Nombre del producto
            binding.tvProductName.text = producto.nombre

            // Descripción del producto
            binding.tvProductDescription.text = producto.descripcion

            // Precio del producto
            binding.tvPrice.text = "Precio: S/.${producto.precio}"

            // Cantidad del producto (suponemos que el carrito maneja una propiedad `cantidad`)
            val cantidad = 1  // Aquí puedes agregar la lógica para obtener la cantidad si la tienes
            binding.tvQuantity.text = "Cantidad: $cantidad"

            // Subtotal (precio * cantidad)
            val subtotal = producto.precio * cantidad
            binding.tvSubtotal.text = "Subtotal: S/.${"%.2f".format(subtotal)}"

            // Imagen del producto (si tienes URL, usa Glide o Picasso)
            Glide.with(binding.ivProductImage.context)
                .load(producto.imagenUrl)  // Asumiendo que `imagenUrl` es la URL de la imagen del producto
                .placeholder(R.drawable.ic_carrito)  // Placeholder en caso de que no haya imagen
                .into(binding.ivProductImage)
        }
    }
}
